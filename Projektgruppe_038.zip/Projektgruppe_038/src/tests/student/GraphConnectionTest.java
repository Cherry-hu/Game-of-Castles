package tests.student;

import base.Edge;
import base.Graph;
import base.Node;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class GraphConnectionTest {
	private Graph<String> g;
	
	@Test
	public void allTest1() {
		g = new Graph();
		Node<String> a = g.addNode("A");
		Node<String> b = g.addNode("B");
		Node<String> c = g.addNode("C");
		Node<String> d = g.addNode("D");
		Node<String> e = g.addNode("E");
		Node<String> f = g.addNode("F");
		Node<String> g1 = g.addNode("G");
		Node<String> h = g.addNode("H");
		
		Edge<String> e1 = g.addEdge(a, b);
		Edge<String> e2 = g.addEdge(a, c);
		Edge<String> e3 = g.addEdge(b, c);
		Edge<String> e4 = g.addEdge(d, c);
		Edge<String> e6 = g.addEdge(f, e);
		Edge<String> e8 = g.addEdge(h, e);
		Edge<String> e9 = g.addEdge(f, h);
		boolean i = g.allNodesConnected();
		assertEquals(false, i);
	}
	@Test
	public void allTest2() {
		g = new Graph();
		Node<String> a = g.addNode("A");
		Node<String> b = g.addNode("B");
		Node<String> c = g.addNode("C");
		Node<String> d = g.addNode("D");
		Node<String> e = g.addNode("E");
		Node<String> f = g.addNode("F");
		Node<String> g1 = g.addNode("G");
		Node<String> h = g.addNode("H");
		
		Edge<String> e1 = g.addEdge(a, b);
		Edge<String> e2 = g.addEdge(a, c);
		Edge<String> e3 = g.addEdge(b, c);
		Edge<String> e4 = g.addEdge(d, c);
		Edge<String> e5 = g.addEdge(e, g1);
		Edge<String> e6 = g.addEdge(f, e);
		Edge<String> e7 = g.addEdge(g1, b);
		Edge<String> e8 = g.addEdge(h, e);
		Edge<String> e9 = g.addEdge(f, h);
		boolean i = g.allNodesConnected();
		assertEquals(true, i);
	}
}
