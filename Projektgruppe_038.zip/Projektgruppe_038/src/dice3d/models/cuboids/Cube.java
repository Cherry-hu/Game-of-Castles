package dice3d.models.cuboids;

public class Cube extends Cuboid {

	public Cube(double x, double y, double z, int size) {
		super(x, y, z, size, size, size);
	}

}
